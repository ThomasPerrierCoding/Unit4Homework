package edu.ranken.thomasperrier.rockpaperscissors;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class ScoresActivity extends AppCompatActivity {

    TextView textViewComputerWins;
    TextView textViewUserWins;
    TextView textViewTotalTies;
    Button buttonNext;
    ImageView imageViewCurrentWinner;

    String computerWins = "0";
    String userWins = "0";
    String totalTies = "0";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sccores);

        imageViewCurrentWinner = findViewById(R.id.imageViewCurrentWinner);
        textViewComputerWins = findViewById(R.id.textViewComputerWins);
        textViewUserWins = findViewById(R.id.textViewUserWins);
        textViewTotalTies = findViewById(R.id.textViewTotalTies);
        buttonNext = findViewById(R.id.buttonNext);

        Intent intent = getIntent();

        Bundle bundle = intent.getExtras();

        computerWins = bundle.getString("COMPWINS");
        userWins = bundle.getString("USERWINS");
        totalTies = bundle.getString("TOTALTIES");

        textViewUserWins.setText(userWins);
        textViewTotalTies.setText(totalTies);
        textViewComputerWins.setText(computerWins);

        if((Integer.valueOf(computerWins) > Integer.valueOf(userWins)) && (Integer.valueOf(computerWins) > Integer.valueOf(totalTies))){
            imageViewCurrentWinner.setImageResource(R.drawable.computer);
        }
        else if((Integer.valueOf(userWins) > Integer.valueOf(computerWins)) && (Integer.valueOf(userWins) > Integer.valueOf(totalTies))){
            imageViewCurrentWinner.setImageResource(R.drawable.user);
        }
        else{
            imageViewCurrentWinner.setImageResource(R.drawable.tiedgame);
        }

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
