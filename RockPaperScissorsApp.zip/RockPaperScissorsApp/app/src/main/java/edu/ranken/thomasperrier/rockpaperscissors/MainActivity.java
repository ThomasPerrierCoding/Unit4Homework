package edu.ranken.thomasperrier.rockpaperscissors;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ImageButton;
import android.content.Intent;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    final String ROCK = "ROCK";
    final String PAPER = "PAPER";
    final String SCISSORS = "SCISSORS";
    final String USER = "USER";
    final String COMPUTER = "COMPUTER";
    final String TIE = "TIE";

    ImageButton imageButtonRock;
    ImageButton imageButtonPaper;
    ImageButton imageButtonScissors;
    TextView textViewComputerChoice;
    TextView textViewUserChoice;
    TextView textViewWinner;
    Button buttonNext;

    Random r = new Random();
    int compChoice = 0;
    int usrChoice = 0;
    int compWins = 0;
    int usrWins = 0;
    int ttlTies = 0;
    String userChoice = "";
    String computerChoice = "";
    String computerWins = "";
    String userWins = "";
    String totalTies = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewComputerChoice = findViewById(R.id.textViewCompChoice);
        textViewUserChoice = findViewById(R.id.textViewUserChoice);
        textViewWinner = findViewById(R.id.textViewWinner);
        imageButtonPaper = findViewById(R.id.imageButtonPaper);
        imageButtonRock = findViewById(R.id.imageButtonRock);
        imageButtonScissors = findViewById(R.id.imageButtonScissors);
        buttonNext = findViewById(R.id.buttonNext);


        imageButtonRock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageButtonPaper.setEnabled(false);
                imageButtonRock.setEnabled(false);
                imageButtonScissors.setEnabled(false);
                buttonNext.setEnabled(true);
                textViewUserChoice.setText(ROCK);
                userChoice = ROCK;
                usrChoice = 1;

                compChoice = r.nextInt(4 - 1) + 1;
                if(compChoice == 1){
                    textViewComputerChoice.setText(ROCK);
                }
                else if(compChoice == 2){
                    textViewComputerChoice.setText(PAPER);
                }
                else{
                    textViewComputerChoice.setText(SCISSORS);
                }
                findWinner();
            }
        });

        imageButtonPaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageButtonPaper.setEnabled(false);
                imageButtonRock.setEnabled(false);
                imageButtonScissors.setEnabled(false);
                buttonNext.setEnabled(true);
                textViewUserChoice.setText(PAPER);
                userChoice = PAPER;
                usrChoice = 2;

                compChoice = r.nextInt(4 - 1) + 1;
                if(compChoice == 1){
                    textViewComputerChoice.setText(ROCK);
                }
                else if(compChoice == 2){
                    textViewComputerChoice.setText(PAPER);
                }
                else{
                    textViewComputerChoice.setText(SCISSORS);
                }
                findWinner();
            }
        });

        imageButtonScissors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageButtonPaper.setEnabled(false);
                imageButtonRock.setEnabled(false);
                imageButtonScissors.setEnabled(false);
                buttonNext.setEnabled(true);
                textViewUserChoice.setText(SCISSORS);
                userChoice = SCISSORS;
                usrChoice = 3;


                compChoice = r.nextInt(4 - 1) + 1;
                if(compChoice == 1){
                    textViewComputerChoice.setText(ROCK);
                }
                else if(compChoice == 2){
                    textViewComputerChoice.setText(PAPER);
                }
                else{
                    textViewComputerChoice.setText(SCISSORS);
                }
                findWinner();
            }
        });

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageButtonPaper.setEnabled(true);
                imageButtonRock.setEnabled(true);
                imageButtonScissors.setEnabled(true);
                buttonNext.setEnabled(false);

                computerWins = String.valueOf(compWins);
                userWins = String.valueOf(usrWins);
                totalTies = String.valueOf(ttlTies);

                Intent intent = new Intent(MainActivity.this,ScoresActivity.class);
                intent.putExtra("COMPWINS", computerWins);
                intent.putExtra("USERWINS", userWins);
                intent.putExtra("TOTALTIES", totalTies);
                intent.getExtras();

                startActivity(intent);
            }
        });

    }

    private void findWinner(){
        if(compChoice == 1 && usrChoice == 1){
            textViewWinner.setText(TIE);
            ttlTies++;
        }
        else if(compChoice == 1 && usrChoice == 2){
            textViewWinner.setText(USER);
            usrWins++;
        }
        else if(compChoice == 1 && usrChoice == 3){
            textViewWinner.setText(COMPUTER);
            compWins++;
        }
        else if(compChoice == 2 && usrChoice == 1){
            textViewWinner.setText(COMPUTER);
            compWins++;
        }
        else if(compChoice == 2 && usrChoice == 2){
            textViewWinner.setText(TIE);
            ttlTies ++;
        }
        else if(compChoice == 2 && usrChoice == 3){
            textViewWinner.setText(USER);
            usrWins++;
        }
        else if(compChoice == 3 && usrChoice == 1){
            textViewWinner.setText(USER);
            usrWins++;
        }
        else if(compChoice == 3 && usrChoice == 2){
            textViewWinner.setText(COMPUTER);
            compWins++;
        }
        else{
            textViewWinner.setText(TIE);
            ttlTies ++;
        }
    }
}
